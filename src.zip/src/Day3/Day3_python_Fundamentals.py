"""number=[10,20,30,40]
coordinates=(5,10)
print(number)
print(coordinates)

a=[100,200,300,400,500,600,700,800,900,1000]
print(a[-3:-1])
print(a[1:7:1])
print(a[-7:-1:2])
"""

a=[70,20,30,40,5,60,10,80,90,1]
a.sort()
print(a)
a.reverse()
print(a)
a.extend([100,200,300])
print(a)
a.insert(3, 500)
print(a)
a.remove(5)
print(a)
a.pop()
print(a)
