Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> a = int(input("Enter first number: "))
Enter first number: 12
>>> b = int(input("Enter second number: "))
Enter second number: 6
>>> print("Addition:", a + b)
Addition: 18
>>> print("Subtraction:", a - b)
Subtraction: 6
>>> print("Multiplication:", a * b)
Multiplication: 72
>>> print("Division:", a / b)
Division: 2.0
