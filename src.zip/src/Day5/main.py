# main.py
import math_operations
result_power = math_operations.power(2, 10)
numbers = [10, 20, 30, 40]
result_average = math_operations.average(numbers)

print("2^10 =", result_power)
print("Average =", result_average)
