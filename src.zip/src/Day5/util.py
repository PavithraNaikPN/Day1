def multifly(a,b):
    return a*b