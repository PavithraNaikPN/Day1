def greet():
    print("Hello, World!")
greet()

def add_numbers(a, b):
    return a + b
result = add_numbers(5, 7)
print( result)

x=10
def show_Value():
    x=5
    print(x)
show_Value()
print(x)

import math
import random
print(math.sqrt(4))
print(random.randint(1,10))_
    
