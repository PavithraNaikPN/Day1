import utils

print(utils.multiply(3, 4))