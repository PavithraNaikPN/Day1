item_name = "Laptop"     
quantity = 2              
price = 499.99            
in_stock = True           
print("Item:", item_name, ", Qty:", quantity, ", Price:", price, ", Available:", in_stock)
total_cost = quantity * price
print("Total Cost:", total_cost)